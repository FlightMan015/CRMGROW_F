import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-input-team',
  templateUrl: './input-team.component.html',
  styleUrls: ['./input-team.component.scss']
})
export class InputTeamComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
